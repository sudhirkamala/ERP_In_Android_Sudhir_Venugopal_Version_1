
## Android ERP App for Database Creation Using SQLite (Java)
This app demonstrates how to implement an ERP (local database) using Android Studio using SQLite.

This Android application provides a versatile scenario for creating, inserting, updating, deleting 
and viewing interactive data with a local SQLite database using Java. This pp can be used for
factories, mechanical institutions and many more the like.

Present Features:
- Local data storage using SQLite (no internet connection required)
- Full CRUD operations (Create, Read, Update, Delete)
- Clean and intuitive user interface

Architecture
- SQLiteOpenHelper: In this app, this DB helper class manages database creation, manipulation. Schema upgrades is a feature to be looked into in the future.
- SQLiteDatabase: Database is created and Used to perform SQL operations such as insert, update, delete, and query.
- Cursor: Used to retrieve and iterate over query results.
  
Working Functionality
1. Database Initialization
   - The app uses a subclass of `SQLiteOpenHelper` to define the database schema (tables, columns, indexes) and manage upgrades.
   - The database is stored locally in the app's private storage area and is not online like for example firebase.
2. CRUD Operations
   - Create**: Insert new records into the database using SQL `INSERT` statements.
   - View: Retrieve data using SQL `SELECT` queries. Results are managed using the `Cursor` class.
   - Update: Modify existing records with SQL `UPDATE` statements.
   - Delete: Remove records using SQL `DELETE` statements.
3. User Interface
   - The UI provides forms and lists for users to interact with the database, such as adding new entries or viewing existing data.
     
Project Structure
- "DBHelper.java": Handles database creation, schema definition, and upgrades.
- "Main_Menu.java": Provides the welcome activity for choosing the required table activity.
- "MainActivity.java": Purchase Order Activity.
- "attendance_activity.java": Attendance Activity.
- "customer.java": Customer Activity.
- "finance_activity.java": Finance Activity.
- "inventory_activity.java": Inventory Activity.
- "marketing.java": Marketing Activity.
- "project_activity.java": Project Activity.
- "supplychain_activity.java": Supply Chain Activity.
- "warehouse_activity.java": Warehouse Activity.
- "work_order.java": Work Order Activity.

How to use the app:
1. Clone or download the project.
2. Open in Android Studio.
3. Build and run on an Android device or emulator.
4. Use the respective button in Main_Menu activity to insert, update, delete or view records.