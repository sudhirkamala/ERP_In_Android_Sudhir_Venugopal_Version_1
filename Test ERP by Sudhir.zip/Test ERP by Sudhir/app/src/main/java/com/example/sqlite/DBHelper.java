package com.example.sqlite;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) {
        super(context, "ERPData.db", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table purchase_order(PO_Number TEXT primary key, PO_Date TEXT, Item_Description TEXT, Purchased_From TEXT, Amount TEXT, If_Returned TEXT, Amount_Reclaimed TEXT)");
        DB.execSQL("create Table work_order(WO_Number TEXT primary key, part_number TEXT, order_date TEXT, order_amount TEXT, completion_date TEXT, If_Returned TEXT, Amount_Reclaimed TEXT)");
        DB.execSQL("create Table customer(Customer_Number TEXT primary key, Customer_Name TEXT, Phone TEXT, E_Mail TEXT, Address TEXT, Customer_Since TEXT)");
        DB.execSQL("create Table finance(company_Name TEXT primary key, Investement TEXT, Loan_Taken TEXT, Assets TEXT, Assest_Cost TEXT, Depreciation TEXT, Balance_Amount TEXT)");
        DB.execSQL("create Table attendance(Employee_Number TEXT primary key, Employee_Name TEXT, Date_Of_Birth TEXT, Date_Of_Induction TEXT, Date_Of_Retirement TEXT, Days_In_Service TEXT, Leaves_Taken TEXT)");
        DB.execSQL("create Table inventory(Inventory_Number TEXT primary key, Item_Name TEXT, Cost TEXT, Date_Of_Induction TEXT, Date_Of_Despatch TEXT, No_Of_Pecies TEXT, Total_Cost TEXT)");
        DB.execSQL("create Table project(Project_Number TEXT primary key, Project_Name TEXT, Project_Start_Date TEXT, Project_End_Date TEXT, Type_Of_Project TEXT, Related_Customer TEXT, Project_Cost TEXT)");
        DB.execSQL("create Table warehouse(Product_Name TEXT primary key, Date_Of_Induction TEXT, Date_Of_Despatch TEXT, Cost TEXT, Number_In_Stock TEXT, Date_Of_Reorder TEXT, Remarks TEXT)");
        DB.execSQL("create Table marketing(Customer_Number TEXT primary key, Item_Marketed TEXT, Number_Of_Products TEXT, Total_Cost TEXT, Brand_Name TEXT, Sales_Executive_Name TEXT, Incentive TEXT)");
        DB.execSQL("create Table supply_chain(Supplier_Number TEXT primary key, Product TEXT, Supplier_Name TEXT, Supply_Date TEXT, Part_Number TEXT, Part_Name TEXT, Amount TEXT)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int ii) {
        DB.execSQL("drop Table if exists purchase_order");
        DB.execSQL("drop Table if exists work_order");
        DB.execSQL("drop Table if exists customer");
        DB.execSQL("drop Table if exists finance");
        DB.execSQL("drop Table if exists attendance");
        DB.execSQL("drop Table if exists inventory");
        DB.execSQL("drop Table if exists project");
        DB.execSQL("drop Table if exists warehouse");
        DB.execSQL("drop Table if exists marketing");
        DB.execSQL("drop Table if exists supply_chain");
    }
    // For Purchase order
    public Boolean insertuserdataPO(String PO_Number, String PO_Date, String Item_Description, String Purchased_From, String Amount, String If_Returned, String Amount_Reclaimed)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("PO_Number", PO_Number);
        contentValues.put("PO_Date", PO_Date);
        contentValues.put("Item_Description", Item_Description);
        contentValues.put("Purchased_From", Purchased_From);
        contentValues.put("Amount", Amount);
        contentValues.put("If_Returned", If_Returned);
        contentValues.put("Amount_Reclaimed", Amount_Reclaimed);
        long result=DB.insert("purchase_order", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }
    public Boolean updateuserdataPO(String PO_Number, String PO_Date, String Item_Description, String Purchased_From, String Amount, String If_Returned, String Amount_Reclaimed)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("PO_Date", PO_Date);
        contentValues.put("Item_Description", Item_Description);
        contentValues.put("Purchased_From", Purchased_From);
        contentValues.put("Amount", Amount);
        contentValues.put("If_Returned", If_Returned);
        contentValues.put("Amount_Reclaimed", Amount_Reclaimed);
        Cursor cursor = DB.rawQuery("Select * from purchase_order where PO_Number = ?", new String[]{PO_Number});
        if (cursor.getCount() > 0) {
            long result = DB.update("purchase_order", contentValues, "name=?", new String[]{PO_Number});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }
    public Boolean deletedataPO(String PO_Number)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from purchase_order where PO_Number = ?", new String[]{PO_Number});
        if (cursor.getCount() > 0) {
            long result = DB.delete("purchase_order", "PO_Number=?", new String[]{PO_Number});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Cursor getdataPO ()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from purchase_order", null);
        return cursor;
    }

    //For Work Order DB Helper
    public Boolean insertuserdataWO(String PO_Number, String Part_Number, String Item_Description, String Purchased_From, String Amount, String If_Returned, String Amount_Reclaimed)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("WO_Number", PO_Number);
        contentValues.put("Part_Number", Part_Number);
        contentValues.put("Order_date", Item_Description);
        contentValues.put("Order_Amount", Purchased_From);
        contentValues.put("Completion_Date", Amount);
        contentValues.put("If_Returned", If_Returned);
        contentValues.put("Amount_Reclaimed", Amount_Reclaimed);
        long result=DB.insert("work_order", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }
    public Boolean updateuserdataWO(String WO_Number, String WO_Date, String Item_Description, String Purchased_From, String Amount, String If_Returned, String Amount_Reclaimed)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("PO_Date", WO_Date);
        contentValues.put("Item_Description", Item_Description);
        contentValues.put("Purchased_From", Purchased_From);
        contentValues.put("Amount", Amount);
        contentValues.put("If_Returned", If_Returned);
        contentValues.put("Amount_Reclaimed", Amount_Reclaimed);
        Cursor cursor = DB.rawQuery("Select * from work_order where WO_Number = ?", new String[]{WO_Number});
        if (cursor.getCount() > 0) {
            long result = DB.update("work_order", contentValues, "WO_Number=?", new String[]{WO_Number});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }
    public Boolean deletedataWO(String WO_Number)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from purchase_order where WO_Number = ?", new String[]{WO_Number});
        if (cursor.getCount() > 0) {
            long result = DB.delete("work_order", "WO_Number=?", new String[]{WO_Number});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Cursor getdataWO ()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from work_order", null);
        return cursor;
    }

    // For customer
    public Boolean insertuserdatacustomer(String Customer_Number, String Customer_Name, String Phone, String E_Mail, String Address, String Customer_Since)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Customer_Number", Customer_Number);
        contentValues.put("Customer_Name", Customer_Name);
        contentValues.put("Phone", Phone);
        contentValues.put("E_Mail", E_Mail);
        contentValues.put("Address", Address);
        contentValues.put("Customer_Since", Customer_Since);
        long result=DB.insert("customer", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }
    public Boolean updateuserdatacustomer(String Customer_Number, String Customer_Name, String Phone, String E_Mail, String Address, String Customer_Since)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Customer_Number", Customer_Number);
        contentValues.put("Customer_Name", Customer_Name);
        contentValues.put("Phone", Phone);
        contentValues.put("E_Mail", E_Mail);
        contentValues.put("Address", Address);
        contentValues.put("Customer_Since", Customer_Since);
        Cursor cursor = DB.rawQuery("Select * from customer where Customer_Number = ?", new String[]{Customer_Number});
        if (cursor.getCount() > 0) {
            long result = DB.update("customer", contentValues, "Customer_Number=?", new String[]{Customer_Number});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }
    public Boolean deletedatacustomer(String Customer_Number)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from customer where Customer_Number = ?", new String[]{Customer_Number});
        if (cursor.getCount() > 0) {
            long result = DB.delete("customer", "Customer_Number=?", new String[]{Customer_Number});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Cursor getdatacustomer ()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from customer", null);
        return cursor;
    }

    // For Finance details
    public Boolean insertuserdatafinance(String Company_Name, String Investment, String Loan_Taken, String Assets, String Asset_Cost, String Depreciation, String Balance_Amount)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Company_Name", Company_Name);
        contentValues.put("Investment", Investment);
        contentValues.put("Loan_Taken", Loan_Taken);
        contentValues.put("Assets", Assets);
        contentValues.put("Asset_Cost", Asset_Cost);
        contentValues.put("Depreciation", Depreciation);
        contentValues.put("Balance_Amount", Balance_Amount);
        long result=DB.insert("finance", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }
    public Boolean updateuserdatafinance(String Company_Name, String Investment, String Loan_Taken, String Assets, String Asset_Cost, String Depreciation, String Balance_Amount)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Company_Name", Company_Name);
        contentValues.put("Investment", Investment);
        contentValues.put("Loan_Taken", Loan_Taken);
        contentValues.put("Assets", Assets);
        contentValues.put("Asset_Cost", Asset_Cost);
        contentValues.put("Depreciation", Depreciation);
        contentValues.put("Balance_Amount", Balance_Amount);
        Cursor cursor = DB.rawQuery("Select * from finance where Company_Name = ?", new String[]{Company_Name});
        if (cursor.getCount() > 0) {
            long result = DB.update("finance", contentValues, "Company_Name=?", new String[]{Company_Name});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }
    public Boolean deletedatafinance(String Company_Name)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from finance where Company_Name = ?", new String[]{Company_Name});
        if (cursor.getCount() > 0) {
            long result = DB.delete("finance", "Company_Name=?", new String[]{Company_Name});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Cursor getdatafinance ()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from finance", null);
        return cursor;
    }

    //For Attendance Details
    public Boolean insertuserdataattendance(String Employee_Number, String Employee_Name, String Date_Of_Birth, String Date_Of_Induction, String Date_Of_Retirement, String Days_In_Service, String Leaves_Taken)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Employee_Number", Employee_Number);
        contentValues.put("Employee_Name", Employee_Name);
        contentValues.put("Date_Of_Birth", Date_Of_Birth);
        contentValues.put("Date_Of_Induction", Date_Of_Induction);
        contentValues.put("Date_Of_Retirement", Date_Of_Retirement);
        contentValues.put("Days_In_Service", Days_In_Service);
        contentValues.put("Leaves_Taken", Leaves_Taken);
        long result=DB.insert("attendance", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }
    public Boolean updateuserdataattendance(String Employee_Number, String Employee_Name, String Date_Of_Birth, String Date_Of_Induction, String Date_Of_Retirement, String Days_In_Service, String Leaves_Taken)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Employee_Number", Employee_Number);
        contentValues.put("Employee_Name", Employee_Name);
        contentValues.put("Date_Of_Birth", Date_Of_Birth);
        contentValues.put("Date_Of_Induction", Date_Of_Induction);
        contentValues.put("Date_Of_Retirement", Date_Of_Retirement);
        contentValues.put("Days_In_Service", Days_In_Service);
        contentValues.put("Leaves_Taken", Leaves_Taken);
        Cursor cursor = DB.rawQuery("Select * from attendance where Employee_Number = ?", new String[]{Employee_Number});
        if (cursor.getCount() > 0) {
            long result = DB.update("attendance", contentValues, "Employee_Number=?", new String[]{Employee_Number});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }
    public Boolean deletedataattendance(String Employee_Number)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from attendance where Employee_Number = ?", new String[]{Employee_Number});
        if (cursor.getCount() > 0) {
            long result = DB.delete("attendance", "Employee_Number=?", new String[]{Employee_Number});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Cursor getdataattendance ()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from attendance", null);
        return cursor;
    }

    // For Inventory Details
    public Boolean insertuserdatainventory(String Inventory_Number, String Item_Name, String Cost, String Date_Of_Induction, String Date_Of_Despatch, String No_Of_Peices, String Total_Cost)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Inventory_Number", Inventory_Number);
        contentValues.put("Item_Name", Item_Name);
        contentValues.put("Cost", Cost);
        contentValues.put("Date_Of_Induction", Date_Of_Induction);
        contentValues.put("Date_Of_Despatch", Date_Of_Despatch);
        contentValues.put("No_Of_Peices", No_Of_Peices);
        contentValues.put("Total_Cost", Total_Cost);
        long result=DB.insert("inventory", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }
    public Boolean updateuserdatainventory(String Inventory_Number, String Item_Name, String Cost, String Date_Of_Induction, String Date_Of_Despatch, String No_Of_Peices, String Total_Cost)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Inventory_Number", Inventory_Number);
        contentValues.put("Item_Name", Item_Name);
        contentValues.put("Cost", Cost);
        contentValues.put("Date_Of_Induction", Date_Of_Induction);
        contentValues.put("Date_Of_Despatch", Date_Of_Despatch);
        contentValues.put("No_Of_Peices", No_Of_Peices);
        contentValues.put("Total_Cost", Total_Cost);
        Cursor cursor = DB.rawQuery("Select * from inventory where Inventory_Number = ?", new String[]{Inventory_Number});
        if (cursor.getCount() > 0) {
            long result = DB.update("inventory", contentValues, "Inventory_Number=?", new String[]{Inventory_Number});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }
    public Boolean deletedatainventory(String Inventory_Number)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from inventory where Inventory_Number = ?", new String[]{Inventory_Number});
        if (cursor.getCount() > 0) {
            long result = DB.delete("inventory", "PO_Number=?", new String[]{Inventory_Number});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Cursor getdatainventory ()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from inventory", null);
        return cursor;
    }

    // For Project Details
    public Boolean insertuserdataproject(String Project_Number, String Project_Name, String Project_Start_Date, String Project_End_Date, String Type_Of_Project, String Related_Customer, String Project_Cost)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Project_Number", Project_Number);
        contentValues.put("Project_Name", Project_Name);
        contentValues.put("Project_Start_Date", Project_Start_Date);
        contentValues.put("Project_End_Date", Project_End_Date);
        contentValues.put("Type_Of_Project", Type_Of_Project);
        contentValues.put("Related_Customer", Related_Customer);
        contentValues.put("Project_Cost", Project_Cost);
        long result=DB.insert("project", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }
    public Boolean updateuserdataproject(String Project_Number, String Project_Name, String Project_Start_Date, String Project_End_Date, String Type_Of_Project, String Related_Customer, String Project_Cost)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Project_Number", Project_Number);
        contentValues.put("Project_Name", Project_Name);
        contentValues.put("Project_Start_Date", Project_Start_Date);
        contentValues.put("Project_End_Date", Project_End_Date);
        contentValues.put("Type_Of_Project", Type_Of_Project);
        contentValues.put("Related_Customer", Related_Customer);
        contentValues.put("Project_Cost", Project_Cost);
        Cursor cursor = DB.rawQuery("Select * from project where Project_Number = ?", new String[]{Project_Number});
        if (cursor.getCount() > 0) {
            long result = DB.update("project", contentValues, "Project_Number=?", new String[]{Project_Number});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }
    public Boolean deletedataproject(String Project_Number)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from project where Project_Number = ?", new String[]{Project_Number});
        if (cursor.getCount() > 0) {
            long result = DB.delete("project", "Project_Number=?", new String[]{Project_Number});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Cursor getdataproject ()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from project", null);
        return cursor;
    }

    // For Warehouse Details
    public Boolean insertuserdatawarehouse(String Product_Name, String Date_Of_Induction, String Date_Of_Despatch, String Cost, String Number_In_Stock, String Date_Of_Reorder, String Remarks)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Product_Name", Product_Name);
        contentValues.put("Date_Of_Induction", Date_Of_Induction);
        contentValues.put("Date_Of_Despatch", Date_Of_Despatch);
        contentValues.put("Cost", Cost);
        contentValues.put("Number_In_Stock", Number_In_Stock);
        contentValues.put("Date_Of_Reorder", Date_Of_Reorder);
        contentValues.put("Remarks", Remarks);
        long result=DB.insert("warehouse", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }
    public Boolean updateuserdatawarehouse(String Product_Name, String Date_Of_Induction, String Date_Of_Despatch, String Cost, String Number_In_Stock, String Date_Of_Reorder, String Remarks)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Product_Name", Product_Name);
        contentValues.put("Date_Of_Induction", Date_Of_Induction);
        contentValues.put("Date_Of_Despatch", Date_Of_Despatch);
        contentValues.put("Cost", Cost);
        contentValues.put("Number_In_Stock", Number_In_Stock);
        contentValues.put("Date_Of_Reorder", Date_Of_Reorder);
        contentValues.put("Remarks", Remarks);
        Cursor cursor = DB.rawQuery("Select * from warehouse where Product_Name = ?", new String[]{Product_Name});
        if (cursor.getCount() > 0) {
            long result = DB.update("warehouse", contentValues, "Product_Name=?", new String[]{Product_Name});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }
    public Boolean deletedatawarehouse(String Product_Name)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from warehouse where Product_Name = ?", new String[]{Product_Name});
        if (cursor.getCount() > 0) {
            long result = DB.delete("warehouse", "Product_Name=?", new String[]{Product_Name});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Cursor getdatawarehouse ()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from warehouse", null);
        return cursor;
    }

    // For Marketing Details
    public Boolean insertuserdatamarketing(String Customer_Number, String Item_Marketed, String Number_Of_Products, String Total_Cost, String Brand_Name, String Sales_Executive_Name, String Incentive)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Customer_Number", Customer_Number);
        contentValues.put("Item_Marketed", Item_Marketed);
        contentValues.put("Number_Of_Products", Number_Of_Products);
        contentValues.put("Total_Cost", Total_Cost);
        contentValues.put("Brand_Name", Brand_Name);
        contentValues.put("Sales_Executive_Name", Sales_Executive_Name);
        contentValues.put("Incentive", Incentive);
        long result=DB.insert("marketing", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }
    public Boolean updateuserdatamarketing(String Customer_Number, String Item_Marketed, String Number_Of_Products, String Total_Cost, String Brand_Name, String Sales_Executive_Name, String Incentive)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Customer_Number", Customer_Number);
        contentValues.put("Item_Marketed", Item_Marketed);
        contentValues.put("Number_Of_Products", Number_Of_Products);
        contentValues.put("Total_Cost", Total_Cost);
        contentValues.put("Brand_Name", Brand_Name);
        contentValues.put("Sales_Executive_Name", Sales_Executive_Name);
        contentValues.put("Incentive", Incentive);
        Cursor cursor = DB.rawQuery("Select * from marketing where Customer_Number = ?", new String[]{Customer_Number});
        if (cursor.getCount() > 0) {
            long result = DB.update("marketing", contentValues, "Customer_Number=?", new String[]{Customer_Number});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }
    public Boolean deletedatamarketing(String Customer_Number)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from marketing where Customer_Number = ?", new String[]{Customer_Number});
        if (cursor.getCount() > 0) {
            long result = DB.delete("marketing", "Customer_Number=?", new String[]{Customer_Number});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Cursor getdatamarketing ()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from marketing", null);
        return cursor;
    }

    // For Supply Chain Details
    public Boolean insertuserdatasupplychain(String Supplier_Number, String Product, String Supplier_Name, String Supply_Date, String Part_Number, String Part_Name, String Amount)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Supplier_Number", Supplier_Number);
        contentValues.put("Product", Product);
        contentValues.put("Supplier_Name", Supplier_Name);
        contentValues.put("Supply_Date", Supply_Date);
        contentValues.put("Part_Number", Part_Number);
        contentValues.put("Part_Name", Part_Name);
        contentValues.put("Amount", Amount);
        long result=DB.insert("supply_chain", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }
    public Boolean updateuserdatasupplychain(String Supplier_Number, String Product, String Supplier_Name, String Supply_Date, String Part_Number, String Part_Name, String Amount)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Supplier_Number", Supplier_Number);
        contentValues.put("Product", Product);
        contentValues.put("Supplier_Name", Supplier_Name);
        contentValues.put("Supply_Date", Supply_Date);
        contentValues.put("Part_Number", Part_Number);
        contentValues.put("Part_Name", Part_Name);
        contentValues.put("Amount", Amount);
        Cursor cursor = DB.rawQuery("Select * from supply_chain where Supplier_Number = ?", new String[]{Supplier_Number});
        if (cursor.getCount() > 0) {
            long result = DB.update("supply_chain", contentValues, "Supplier_Number=?", new String[]{Supplier_Number});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }
    public Boolean deletedatasupplychain(String Supplier_Number)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from supply_chain where Supplier_Number = ?", new String[]{Supplier_Number});
        if (cursor.getCount() > 0) {
            long result = DB.delete("supply_chain", "Supplier_Number=?", new String[]{Supplier_Number});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Cursor getdatasupplychain()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from supply_chain", null);
        return cursor;
    }
}