package com.example.sqlitestudentapp;
//import com.example.sqlite;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


import androidx.appcompat.app.AppCompatActivity;
import com.example.sqlite.MainActivity;
import com.example.sqlite.attendance_activity;
import com.example.sqlite.customer;
import com.example.sqlite.finance_activity;
import com.example.sqlite.inventory_activity;
import com.example.sqlite.marketing_activity;
import com.example.sqlite.project_activity;
import com.example.sqlite.supplychain_activity;
import com.example.sqlite.warehouse_activity;
import com.example.sqlite.work_order;

import com.example.sqlite.R;
import com.example.sqlite.work_order;

public class Main_Menu extends AppCompatActivity {
    Button userbtnPO, userbtnWO, userbtnCustomer, userbtnFinance, userbtnAttendance, userbtnInventory, userbtnProject, userbtnWarehouse, userbtnMarketing, userbtnSupplyChain;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu);

//        Intent intent = new Intent();
//        String value = intent.getStringExtra("key");

        userbtnPO = findViewById(R.id.btnPO);
        userbtnWO = findViewById(R.id.btnWO);
        userbtnCustomer = findViewById(R.id.btnCustomer);
        userbtnFinance = findViewById(R.id.btnFinance);
        userbtnAttendance = findViewById(R.id.btnAttendance);
        userbtnInventory = findViewById(R.id.btnInventory);
        userbtnProject = findViewById(R.id.btnProject);
        userbtnWarehouse = findViewById(R.id.btnWarehouse);
        userbtnMarketing = findViewById(R.id.btnMarketing);
        userbtnSupplyChain = findViewById(R.id.btnSupplychain);

        userbtnPO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main_Menu.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
//                Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
//                startActivity(myIntent);
//                Intent myIntent = new Intent(Main_Menu.this, MainActivity.class);
//                String value = myIntent.getStringExtra("key");
//                myIntent.putExtra("key", value); //Optional parameters
//                Main_Menu.this.startActivity(myIntent);
//            Intent intent1 = new Intent(Main_Menu.this, MainActivity.class);
//            startActivity(intent1);
        });

        userbtnWO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main_Menu.this, work_order.class);
                startActivity(intent);
                finish();
            }
//                Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
//                startActivity(myIntent);
//                Intent myIntent = new Intent(Main_Menu.this, MainActivity.class);
//                String value = myIntent.getStringExtra("key");
//                myIntent.putExtra("key", value); //Optional parameters
//                Main_Menu.this.startActivity(myIntent);
//            Intent intent1 = new Intent(Main_Menu.this, MainActivity.class);
//            startActivity(intent1);
        });

        userbtnCustomer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main_Menu.this, customer.class);
                startActivity(intent);
                finish();
            }
//                Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
//                startActivity(myIntent);
//                Intent myIntent = new Intent(Main_Menu.this, MainActivity.class);
//                String value = myIntent.getStringExtra("key");
//                myIntent.putExtra("key", value); //Optional parameters
//                Main_Menu.this.startActivity(myIntent);
//            Intent intent1 = new Intent(Main_Menu.this, MainActivity.class);
//            startActivity(intent1);
        });

        userbtnFinance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main_Menu.this, finance_activity.class);
                startActivity(intent);
                finish();
            }
//                Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
//                startActivity(myIntent);
//                Intent myIntent = new Intent(Main_Menu.this, MainActivity.class);
//                String value = myIntent.getStringExtra("key");
//                myIntent.putExtra("key", value); //Optional parameters
//                Main_Menu.this.startActivity(myIntent);
//            Intent intent1 = new Intent(Main_Menu.this, MainActivity.class);
//            startActivity(intent1);
        });

        userbtnAttendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main_Menu.this, attendance_activity.class);
                startActivity(intent);
                finish();
            }
//                Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
//                startActivity(myIntent);
//                Intent myIntent = new Intent(Main_Menu.this, MainActivity.class);
//                String value = myIntent.getStringExtra("key");
//                myIntent.putExtra("key", value); //Optional parameters
//                Main_Menu.this.startActivity(myIntent);
//            Intent intent1 = new Intent(Main_Menu.this, MainActivity.class);
//            startActivity(intent1);
        });


        userbtnInventory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main_Menu.this, inventory_activity.class);
                startActivity(intent);
                finish();
            }
//                Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
//                startActivity(myIntent);
//                Intent myIntent = new Intent(Main_Menu.this, MainActivity.class);
//                String value = myIntent.getStringExtra("key");
//                myIntent.putExtra("key", value); //Optional parameters
//                Main_Menu.this.startActivity(myIntent);
//            Intent intent1 = new Intent(Main_Menu.this, MainActivity.class);
//            startActivity(intent1);
        });

        userbtnProject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main_Menu.this, project_activity.class);
                startActivity(intent);
                finish();
            }
//                Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
//                startActivity(myIntent);
//                Intent myIntent = new Intent(Main_Menu.this, MainActivity.class);
//                String value = myIntent.getStringExtra("key");
//                myIntent.putExtra("key", value); //Optional parameters
//                Main_Menu.this.startActivity(myIntent);
//            Intent intent1 = new Intent(Main_Menu.this, MainActivity.class);
//            startActivity(intent1);
        });

        userbtnWarehouse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main_Menu.this, warehouse_activity.class);
                startActivity(intent);
                finish();
            }
//                Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
//                startActivity(myIntent);
//                Intent myIntent = new Intent(Main_Menu.this, MainActivity.class);
//                String value = myIntent.getStringExtra("key");
//                myIntent.putExtra("key", value); //Optional parameters
//                Main_Menu.this.startActivity(myIntent);
//            Intent intent1 = new Intent(Main_Menu.this, MainActivity.class);
//            startActivity(intent1);
        });

        userbtnMarketing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main_Menu.this, marketing_activity.class);
                startActivity(intent);
                finish();
            }
//                Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
//                startActivity(myIntent);
//                Intent myIntent = new Intent(Main_Menu.this, MainActivity.class);
//                String value = myIntent.getStringExtra("key");
//                myIntent.putExtra("key", value); //Optional parameters
//                Main_Menu.this.startActivity(myIntent);
//            Intent intent1 = new Intent(Main_Menu.this, MainActivity.class);
//            startActivity(intent1);
        });

        userbtnSupplyChain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main_Menu.this, supplychain_activity.class);
                startActivity(intent);
                finish();
            }
//                Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
//                startActivity(myIntent);
//                Intent myIntent = new Intent(Main_Menu.this, MainActivity.class);
//                String value = myIntent.getStringExtra("key");
//                myIntent.putExtra("key", value); //Optional parameters
//                Main_Menu.this.startActivity(myIntent);
//            Intent intent1 = new Intent(Main_Menu.this, MainActivity.class);
//            startActivity(intent1);
        });

    }
}


