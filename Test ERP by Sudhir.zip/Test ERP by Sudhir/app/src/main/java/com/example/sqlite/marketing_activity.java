package com.example.sqlite;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class marketing_activity extends AppCompatActivity {
    EditText customernumber, itemmarketed, numberofproducts, totalcost, brandname, salesexecutivename, incentive;
    Button insert, update, delete, view, back;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.marketing);
        customernumber = findViewById(R.id.edtsuppliernumber);
        itemmarketed = findViewById(R.id.edtproduct);
        numberofproducts = findViewById(R.id.edtsuppliername);
        totalcost = findViewById(R.id.edtsupplydate);
        brandname = findViewById(R.id.edtpartnumber);
        salesexecutivename = findViewById(R.id.edtpartname);
        incentive = findViewById(R.id.edtsupplyamount);

        insert = findViewById(R.id.btnInsert);
        update = findViewById(R.id.btnUpdate);
        delete = findViewById(R.id.btnDelete);
        view = findViewById(R.id.btnView);
        back = findViewById(R.id.btnBack);

        DB = new DBHelper(this);
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String customernumberTXT = customernumber.getText().toString();
                String itemmarketedTXT = itemmarketed.getText().toString();
                String numberofproductsTXT = numberofproducts.getText().toString();
                String totalcostTXT = totalcost.getText().toString();
                String brandnameTXT = brandname.getText().toString();
                String salesexecutivenameTXT = salesexecutivename.getText().toString();
                String incentiveTXT = incentive.getText().toString();

                Boolean checkinsertdata = DB.insertuserdatamarketing(customernumberTXT, itemmarketedTXT, numberofproductsTXT, totalcostTXT, brandnameTXT, salesexecutivenameTXT, incentiveTXT);
                if(checkinsertdata==true)
                    Toast.makeText(marketing_activity.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(marketing_activity.this, "New Entry Not Inserted", Toast.LENGTH_SHORT).show();
            }        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                String nameTXT = name.getText().toString();
//                String contactTXT = contact.getText().toString();
//                String dobTXT = dob.getText().toString();
                String customernumberTXT = customernumber.getText().toString();
                String itemmarketedTXT = itemmarketed.getText().toString();
                String numberofproductsTXT = numberofproducts.getText().toString();
                String totalcostTXT = totalcost.getText().toString();
                String brandnameTXT = brandname.getText().toString();
                String salesexecutivenameTXT = salesexecutivename.getText().toString();
                String incentiveTXT = incentive.getText().toString();


                Boolean checkupdatedata = DB.updateuserdatamarketing(customernumberTXT, itemmarketedTXT, numberofproductsTXT, totalcostTXT, brandnameTXT, salesexecutivenameTXT, incentiveTXT);
                if(checkupdatedata==true)
                    Toast.makeText(marketing_activity.this, "Entry Updated", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(marketing_activity.this, "New Entry Not Updated", Toast.LENGTH_SHORT).show();
            }        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String customernumberTXT = customernumber.getText().toString();
                Boolean checkudeletedata = DB.deletedatamarketing(customernumberTXT);
                if(checkudeletedata==true)
                    Toast.makeText(marketing_activity.this, "Entry Deleted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(marketing_activity.this, "Entry Not Deleted", Toast.LENGTH_SHORT).show();
            }        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = DB.getdatamarketing();
                if(res.getCount()==0){
                    Toast.makeText(marketing_activity.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext()){
                    buffer.append("PO Number :"+res.getString(0)+"\n");
                    buffer.append("PO Date :"+res.getString(1)+"\n");
                    buffer.append("PO Description :"+res.getString(2)+"\n");
                    buffer.append("Purchased From :"+res.getString(3)+"\n");
                    buffer.append("Amount :"+res.getString(4)+"\n");
                    buffer.append("If Returned :"+res.getString(5)+"\n");
                    buffer.append("Amount Reclaimed :"+res.getString(6)+"\n\n");
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(marketing_activity.this);
                builder.setTitle("Marketing Entries");
                builder.setMessage(buffer.toString());
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Perform action
                        // dialog.dismiss() is implicitly called here
                    }
                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Perform action (or just close)
                        // dialog.dismiss() is implicitly called here
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(marketing_activity.this, com.example.sqlitestudentapp.Main_Menu.class);
                startActivity(intent);
                finish();
//                Intent myIntent = new Intent(getApplicationContext(), com.example.sqlitestudentapp.Main_Menu.class);
//                startActivity(myIntent);
//                Intent myIntent = new Intent(MainActivity.this, com.example.sqlitestudentapp.Main_Menu.class);
//                String value = myIntent.getStringExtra("key");
//                myIntent.putExtra("key", value); //Optional parameters
//                MainActivity.this.startActivity(myIntent);
            }
//                Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
//                startActivity(myIntent);
//                Intent myIntent = new Intent(Main_Menu.this, MainActivity.class);
//                String value = myIntent.getStringExtra("key");
//                myIntent.putExtra("key", value); //Optional parameters
//                Main_Menu.this.startActivity(myIntent);
//            Intent intent1 = new Intent(Main_Menu.this, MainActivity.class);
//            startActivity(intent1);
        });

    }}
