package com.example.sqlite;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class project_activity extends AppCompatActivity {
    EditText projectnumber, projectname, projectstartdate, projectenddate, typeofproject, relatedcustomer, projectcost;
    Button insert, update, delete, view, back;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.project);
        projectnumber = findViewById(R.id.edtsuppliernumber);
        projectname = findViewById(R.id.edtproduct);
        projectstartdate = findViewById(R.id.edtsuppliername);
        projectenddate = findViewById(R.id.edtsupplydate);
        typeofproject = findViewById(R.id.edtpartnumber);
        relatedcustomer = findViewById(R.id.edtpartname);
        projectcost = findViewById(R.id.edtsupplyamount);

        insert = findViewById(R.id.btnInsert);
        update = findViewById(R.id.btnUpdate);
        delete = findViewById(R.id.btnDelete);
        view = findViewById(R.id.btnView);
        back = findViewById(R.id.btnBack);

        DB = new DBHelper(this);
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String projectnumberTXT = projectnumber.getText().toString();
                String projectnameTXT = projectname.getText().toString();
                String projectstartdateTXT = projectstartdate.getText().toString();
                String projectenddateTXT = projectenddate.getText().toString();
                String typeofprojectTXT = typeofproject.getText().toString();
                String relatedcustomerTXT = relatedcustomer.getText().toString();
                String projectcostTXT = projectcost.getText().toString();

                Boolean checkinsertdata = DB.insertuserdataproject(projectnumberTXT, projectnameTXT, projectstartdateTXT, projectenddateTXT, typeofprojectTXT, relatedcustomerTXT, projectcostTXT);
                if(checkinsertdata==true)
                    Toast.makeText(project_activity.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(project_activity.this, "New Entry Not Inserted", Toast.LENGTH_SHORT).show();
            }        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                String nameTXT = name.getText().toString();
//                String contactTXT = contact.getText().toString();
//                String dobTXT = dob.getText().toString();
                String projectnumberTXT = projectnumber.getText().toString();
                String projectnameTXT = projectname.getText().toString();
                String projectstartdateTXT = projectstartdate.getText().toString();
                String projectenddateTXT = projectenddate.getText().toString();
                String typeofprojectTXT = typeofproject.getText().toString();
                String relatedcustomerTXT = relatedcustomer.getText().toString();
                String projectcostTXT = projectcost.getText().toString();

                Boolean checkupdatedata = DB.updateuserdataproject(projectnumberTXT, projectnameTXT, projectstartdateTXT, projectenddateTXT, typeofprojectTXT, relatedcustomerTXT, projectcostTXT);
                if(checkupdatedata==true)
                    Toast.makeText(project_activity.this, "Entry Updated", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(project_activity.this, "New Entry Not Updated", Toast.LENGTH_SHORT).show();
            }        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String projectnumberTXT = projectnumber.getText().toString();
                Boolean checkudeletedata = DB.deletedataproject(projectnumberTXT);
                if(checkudeletedata==true)
                    Toast.makeText(project_activity.this, "Entry Deleted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(project_activity.this, "Entry Not Deleted", Toast.LENGTH_SHORT).show();
            }        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = DB.getdataproject();
                if(res.getCount()==0){
                    Toast.makeText(project_activity.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext()){
                    buffer.append("PO Number :"+res.getString(0)+"\n");
                    buffer.append("PO Date :"+res.getString(1)+"\n");
                    buffer.append("PO Description :"+res.getString(2)+"\n");
                    buffer.append("Purchased From :"+res.getString(3)+"\n");
                    buffer.append("Amount :"+res.getString(4)+"\n");
                    buffer.append("If Returned :"+res.getString(5)+"\n");
                    buffer.append("Amount Reclaimed :"+res.getString(6)+"\n\n");
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(project_activity.this);
                builder.setTitle("Project Entries");
                builder.setMessage(buffer.toString());
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Perform action
                        // dialog.dismiss() is implicitly called here
                    }
                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Perform action (or just close)
                        // dialog.dismiss() is implicitly called here
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(project_activity.this, com.example.sqlitestudentapp.Main_Menu.class);
                startActivity(intent);
                finish();
//                Intent myIntent = new Intent(getApplicationContext(), com.example.sqlitestudentapp.Main_Menu.class);
//                startActivity(myIntent);
//                Intent myIntent = new Intent(MainActivity.this, com.example.sqlitestudentapp.Main_Menu.class);
//                String value = myIntent.getStringExtra("key");
//                myIntent.putExtra("key", value); //Optional parameters
//                MainActivity.this.startActivity(myIntent);
            }
//                Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
//                startActivity(myIntent);
//                Intent myIntent = new Intent(Main_Menu.this, MainActivity.class);
//                String value = myIntent.getStringExtra("key");
//                myIntent.putExtra("key", value); //Optional parameters
//                Main_Menu.this.startActivity(myIntent);
//            Intent intent1 = new Intent(Main_Menu.this, MainActivity.class);
//            startActivity(intent1);
        });

        //For Workorder

    }}
